#pragma once
#define K 1
#define AREASIZE 600
#define BLOCKSIZE 40
#define SELLITEM_SIZE 11
#define ITEMSIZE 80*K
#define FONTSIZE BLOCKSIZE*K
#define SIZE 600*K
#define MAP_NUM 2
#define SCREENSIZE 600*K
