﻿// test.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#include "Charactor.h"
#include "Shop.h"
#include "Area.h"
#include "Target.h"
//void Areainit(AreaList& a,int& x);
int main() {
	int x = 0;
	NewAreaList ar(x,5000);
	ar.add_Barrier(10, 2, 0);
	for (int i = 0; i < 100; i++)
	{
		ar.add_Barrier(rand()%15, rand() % 15, rand() % 9);
	}
	for (int i = 0; i < 20; i++)
	{
		ar.add_Enermy(rand() % 15, rand() % 15, rand() % 9);
	}
	Shop a;
	a.add_product(NULL);
	a.add_product(NULL);
	a.add_product(NULL);
	a.add_product(NULL);
	a.add_product(NULL);
	a.add_product(NULL);
	Salesman vill;
	vill.link(&a);
	ar.add_Salesman(10, 10, 0, &vill);
	Hero body(100,100);
	int y = 0;
	IMAGE img;
	IMAGE chara;
	HeroMoveAttribute * hero = new HeroMoveAttribute(0,0);
	hero->link(&ar);
	hero->set_body(&body);
	initgraph(500, 500);
	setbkmode(TRANSPARENT);
	loadimage(&img, _T("background.png"), 5000, 600,false);
	loadimage(&chara, _T("charactor.png"), 40, 40, false);
	bool running = true;
	ExMessage msg;
	initgraph(600, 700);
	setfillcolor(RGB(128, 128, 128));
	BeginBatchDraw();

	while (running)
	{
		DWORD beginTime = GetTickCount();			// 记录循环开始时间

		// 消息处理
		while (peekmessage(&msg))
		{
			hero->judge(msg, running, a);
		}
		cleardevice();								// 清除屏幕
		putimage(-x, 0, &img);
		hero->move();
		ar.load(x/AREASIZE);
		hero->put_solided();
		settextcolor(RGB(255, 255, 255));
		settextstyle(20, 0, _T("Arial"));
		TCHAR buf[50];
		_stprintf_s(buf, _T("HP: %d"), body.getHp());
		outtextxy(10, 610, buf);
		_stprintf_s(buf, _T("ATK: %d"), body.getAtk());
		outtextxy(10, 640, buf);
		_stprintf_s(buf, _T("DEF: %d"), body.getDef());
		outtextxy(10, 670, buf);
		FlushBatchDraw();
		// 帧延时
		DWORD endTime = GetTickCount();				// 记录循环结束时间
		DWORD elapsedTime = endTime - beginTime;	// 计算循环耗时
		if (elapsedTime < 1000 / 120)				// 按每秒60帧进行补时
			Sleep(1000 / 120 - elapsedTime);
	}

	EndBatchDraw();
	closegraph();
	return 0;
}
