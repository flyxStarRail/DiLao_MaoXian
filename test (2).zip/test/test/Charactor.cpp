#include "Charactor.h"
#include "Area.h"
#include "Target.h"
void putimage_alpha(int x, int y, IMAGE* img)
{
	//����������ʾ͸��ͼ��
	int w = img->getwidth();
	int h = img->getheight();
	AlphaBlend(GetImageHDC(NULL), x, y, w, h, GetImageHDC(img), 0, 0, w, h, { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA });
}


void HeroMoveAttribute::link(NewAreaList* temp) {
	islink = true;
	this->m = temp;
	if (m->isLink())
	{
		return;
	}
	m->link(this);
};
void HeroMoveAttribute::move()
{
	isMove = isLeft || isRight || isUp||isDown;
	int temp_y = y;
	int& screen_x = m->get_screen_x();
	int temp_real_x = x+screen_x;
	//��������һ֡�ڽ�ɫ���ƶ�
	if (x < 20 && isLeft) isSpeed = false;
	int screen_temp = screen_x;
	if (x > 550 && isRight ) isSpeed = false;
	step = isSpeed ? 10 : 5;
	x -= isLeft ? step - 5 : 0;
	screen_x -= isLeft ? 5 : 0;
	screen_x += isRight ? 5 : 0;
	x += isRight ? step - 5 : 0;
	y += isUp ? step : 0;
	y -= isDown ? step : 0;
	y = y < 0 ? 0 : y;
	y = y > 560 ? 560 : y;
	screen_x = screen_x < 0 ? 0 : screen_x;
	if (m->Meet())
	{

		x > 550 && isLeft ? screen_x = screen_temp : 0;
		x < 10 && isRight ? screen_x = screen_temp : 0;
		
		int temp_x = temp_real_x - screen_x;
		x = temp_x;
		y = temp_y;
		cout << "\nMEET\n";
	}
}

CharactorMoveAttribute::CharactorMoveAttribute(int x,int y)
{
	this->x = x;
	this->y = y;
	step = 5;
}

HeroMoveAttribute::HeroMoveAttribute(int x, int y) :CharactorMoveAttribute(x, y), islink(false), isMove(false), t(0)
{ 
	isDown = isLeft = isRight = isUp = isSpeed = isdamaged = isAttck = is_img_left = 0;
	loadimage(&img[0][0], _T("move_0.png"), 40, 40, false);
	loadimage(&img[0][1], _T("move_1.png"), 40, 40, false);
	loadimage(&img[1][0], _T("lmove_0.png"), 40, 40, false);
	loadimage(&img[1][1], _T("lmove_1.png"), 40, 40, false);
}

void HeroMoveAttribute::judge(ExMessage & msg,bool & running,Shop& a)
{
	//�ú��������жϴ�ʱ���µ���ʲô��
	if (msg.message == WM_KEYDOWN)			// ���°�������
	{
		switch (msg.vkcode)
		{
		case 'w':
		case 'W':
		case VK_UP:
			isDown = 1;
			break;

		case 's':
		case 'S':
		case VK_DOWN:
			isUp = 1;
			break;

		case 'a':
		case 'A':
		case VK_LEFT:
			is_img_left = 1;
			isLeft = 1;
			break;

		case 'd':
		case 'D':
		case VK_RIGHT:
			is_img_left = 0;
			isRight = 1;
			break;

		case 'h':
		case 'H':
			isSpeed = 1;
			break;
		case 'b':
		case 'B':
			//�����̵�
			isDown = 0;			isUp = 0;			isLeft = 0;			isRight = 0;			isSpeed = 0;
			//a.ShopEnter();
			break;

		case VK_ESCAPE:
			running = false;
			break;
		}
	}
	if (msg.message == WM_KEYUP)			// �ɿ���������
	{
		switch (msg.vkcode)
		{
		case 'w':
		case 'W':
		case VK_UP:
			isDown = 0;
			break;

		case 's':
		case 'S':
		case VK_DOWN:
			isUp = 0;
			break;

		case 'a':
		case 'A':
		case VK_LEFT:
			isLeft = 0;
			break;

		case 'd':
		case 'D':
		case VK_RIGHT:
			isRight = 0;
			break;
		case 'h':
		case 'H':
			isSpeed = 0;
			break;
		}

	}
}
//����ĺ�����ûд��
void HeroMoveAttribute::put_solided()
{
	
	if (isMove)
	{
		t++;
		int n;
		n = isSpeed ? 3 : 15;
		t = t % (2 * n);
		putimage_alpha(x, y, &img[is_img_left][t/n]);
	}
	else {
		putimage_alpha(x, y, &img[is_img_left][0]);
	}
	//putimage(x, y, &img);
}
void HeroMoveAttribute::set_body(Hero* temp)
{
	body = temp;
	body->link_attr(this);
}

static int screen2ph(int x, int screen_x) 
{
	return x + screen_x;
}

