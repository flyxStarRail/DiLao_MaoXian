#pragma once
#include <iostream>
#include "Props.h"
#include "Charactor.h"

using namespace std;

class Hero;
//class Target {
//public:
//    virtual bool interact(Hero* hero) = 0; // ���齻��
//};


class Block
{
protected:
    bool flag;
public:
    Block(bool f) :flag(f) {};
    void change_flag() { flag = !flag; };
    bool getflag() { return flag; };
    virtual bool interact(Hero* hero) = 0;

    //virtual bool interactor() = 0;
    virtual void print(int x, int y) = 0;
};

typedef Block Target;

// NPC�����࣬��������Ϊ��
//class NPC :virtual public Block {
//public:
//    bool interact(Hero* hero) override {
//        return true;
//    }
//};

class Person  {
protected:
    int atk, def, hp;
public:
    Person(int atk, int hp, int def) : atk(atk), hp(hp), def(def) {}
    //virtual ~Person() {}
    // ���⽻��������ʵ��
    int getAtk() const { return atk; }
    int getDef() const { return def; }
    int getHp() const { return hp; }
    void setHp(int hp) { this->hp = hp; }
    void setAtk(int atk) { this->atk = atk; }
    void setDef(int def) { this->def = def; }
};

// Ӣ����
class Hero : 
    public Person 
{
protected:
    int SellItemID[10] = { 0 };
    int gold;
    HeroMoveAttribute* attr;
public:
    Hero(int atk, int hp, int def = 0, int gold = 0)
        : Person(atk, hp, def), gold(gold){
    }
    bool interact(Target* target) {
        return target->interact(this);
    }
    bool interact(Hero* other) {
        cout << "Hello" << endl;
        return true;
    }
    void link_attr(HeroMoveAttribute* temp) { attr = temp; };
    void clearattr() { attr->attrclear(); };
    int getGold() const { return gold; }
    void setGold(int g) { gold = g; }
    HeroMoveAttribute* getattr() { return attr; };
};

// ������
class Enermy : public Person,virtual public Block 
{
public:
    Enermy(int atk, int hp, int def = 0) : Person(atk, hp, def),Block(0) {};
    //void print(int x, int y) {};
    void print(int x, int y) {
        IMAGE img;
        loadimage(&img, _T("zombie.png"), 40, 40, false);

        //setfillcolor(RED); 
        //fillrectangle(x, y, x + 40, y + 40); 
        putimage_alpha(x, y, &img);
    };
    bool interact(Hero* hero) override;
};

// ������
class Salesman : virtual public Block
{
protected:
    //Props* itemList[10];
    Shop* shop;
    //int itemCount[10] = { 0 };
public:
    void Enter(Hero* hero)
    {
        shop->ShopEnter(hero);
    };
    void link(Shop* temp) { shop = temp; };
    bool interact(Hero* hero) override;
    bool buyItem(Hero* hero);
    bool sellItem(Hero* hero);
    void print(int,int);
    Salesman() :Block(0){};
};
